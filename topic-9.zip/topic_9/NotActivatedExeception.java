

/**
 * NotActivatedExeception
 */
public class NotActivatedExeception extends Exception{


    public NotActivatedExeception(){

    }
    
    public NotActivatedExeception(String message){
        super(message);
    }
}
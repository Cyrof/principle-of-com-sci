
/**
 * EmptyExeception
 */
public class EmptyExeception extends Exception {

    public EmptyExeception(){

    }

    public EmptyExeception(String message){
        super(message);
    }
    
}